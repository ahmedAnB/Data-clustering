#! /bin/bash

dir=$(dirname "$0")

usage () {
            cat << EOF
Usage: $0 [options]

	Copy required files (*.sty, *.jpg, ...) locally, to avoid
	depending on /usr/local/common/TEXINPUTS/ (usefull to start
	working from a workstation, and keep things compilable on
	one's laptop)

Options:
	--lettre	Install LaTeX files for a (french) letter.
	--report	Install LaTeX files for a technical report.
	--student-report Install LaTeX files for a student report.

	--main FILE.tex Install template (example) file as FILE.tex.

	--help	This help message.

Example:

Copy *.sty and *.jpg files to the current directory to start a new
letter in file ma-lettre.tex:

\$ $0 --lettre --main ma-lettre.tex
The following files have been copied in the current directory:
lettre.sty verimag.sty logoverimag.jpg logo-uga.png cnrs-80.jpg Grenoble-INP_cmjn.pdf

You can now try to compile with:

pdflatex ma-lettre.tex

or

latex ma-lettre.tex
EOF
}

what=""
files=()
main=""
logos=(logoverimag.jpg logo-uga.png cnrs-80.jpg Grenoble-INP_cmjn.pdf)

while test $# -ne 0; do
    case "$1" in
        "--help"|"-h")
            usage
            exit 0
            ;;
	"--main")
	    shift
	    main=$1
	    ;;
        "--lettre")
	    what=lettre
	    texmainfile=exemplelettre.tex
	    texfiles=(lettre.sty verimag.sty)
            ;;
	"--report")
	    what=report
	    texmainfile=examplereport.tex
	    texfiles=(verimagreport.sty verimag.sty)
	    logos=("${logos[@]}" background.jpg)
	    ;;
	"--student-report")
	    what=student-report
	    texmainfile=exampleverimagstudent.tex
	    texfiles=(verimagstudent.sty verimag.sty)
	    ;;
        *)
            echo "unrecognized option $1"
            usage
            exit 1
            ;;
    esac
    shift
done

if [ "$what" = "" ]; then
    echo "I don't know what to do!"
    echo "Please, use either --lettre or --report."
    exit 1
fi

if [ "$main" = "" ]; then
    main=$texmainfile
fi

if [ "$files" = "" ]; then
    files=("${texfiles[@]}" "${logos[@]}")
fi

cp "$dir"/"$texmainfile" "$main"
cp "${files[@]/#/$dir/}" .
perl -pi -e "s@$dir/*@@" "${texfiles[@]}" "$main"

echo "The following files have been copied in the current directory:
${files[@]}

You can now try to compile with:

pdflatex $main

or

latex $main"
